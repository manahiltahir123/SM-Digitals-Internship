/*
 * Integration seam for Athar's registration API.
 * No API URL or payload contract was provided in the Task 4 project, so this
 * module deliberately does not guess either. Configure the host application
 * with window.ATHAR_REGISTER_INTERN(payload) => Promise<ResponseLike>.
 */
(function () {
  function submitMockRegistration(payload) {
    // TEMPORARY LOCAL MOCK: replace this fallback with Athar's confirmed API
    // integration once its endpoint and payload contract are provided.
    return new Promise((resolve) => {
      window.setTimeout(() => {
        resolve({ success: true, mock: true, registration: payload });
      }, 900);
    });
  }

  async function submitInternRegistration(payload) {
    // The real Athar adapter remains isolated. It is used only when supplied
    // by the host application; no endpoint, credentials, or payload format is guessed here.
    if (typeof window.ATHAR_REGISTER_INTERN === 'function') {
      return window.ATHAR_REGISTER_INTERN(payload);
    }

    return submitMockRegistration(payload);
  }

  window.InternRegistrationService = { submitInternRegistration };
}());
