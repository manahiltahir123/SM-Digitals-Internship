/*
 * DEMO REPORT DATA - Temporary placeholder for Athar's real report data
 * 
 * This file contains demo/placeholder interview report data that will be replaced
 * by Athar's real report data when available. The structure is designed to match
 * the expected format from the real report generation system.
 * 
 * To replace with real data:
 * 1. Remove or replace this file with Athar's report data integration
 * 2. Ensure the real data structure matches the expected format below
 * 3. Update the data source in interview-summary.js to point to the real API
 */

const DEMO_REPORT_DATA = {
  overallScore: 85,
  
  dimensions: [
    {
      name: "Technical Skills",
      score: 90,
      maxScore: 100
    },
    {
      name: "Communication",
      score: 82,
      maxScore: 100
    },
    {
      name: "Problem Solving",
      score: 88,
      maxScore: 100
    },
    {
      name: "Cultural Fit",
      score: 78,
      maxScore: 100
    }
  ],
  
  strengths: [
    "Strong technical background in web development and AI",
    "Excellent problem-solving approach with multiple solution strategies",
    "Good understanding of modern frameworks and best practices",
    "Clear and articulate communication skills",
    "Demonstrated ability to work with complex distributed systems"
  ],
  
  weaknesses: [
    "Limited experience with large-scale enterprise applications",
    "Could improve knowledge of testing methodologies",
    "Needs more exposure to performance optimization techniques",
    "Limited experience with team collaboration tools"
  ],
  
  recommendation: "Hire",
  
  keyQuotes: [
    {
      quote: "I think React has matured significantly over the years. The introduction of hooks was a game-changer.",
      context: "Front-end frameworks discussion"
    },
    {
      quote: "I would implement several strategies: loading states, caching, optimistic UI updates, and progressive loading.",
      context: "Technical challenge response"
    },
    {
      quote: "I believe in a testing pyramid approach. Unit tests, integration tests, and end-to-end tests.",
      context: "Testing philosophy"
    },
    {
      quote: "For complex state with many interactions, I prefer Redux with Redux Toolkit - it provides better debugging tools.",
      context: "State management preferences"
    }
  ],
  
  interviewDuration: "09:00",
  interviewDate: new Date().toISOString(),
  candidateName: "Demo Candidate"
};

// Export for use in the summary page
if (typeof module !== 'undefined' && module.exports) {
  module.exports = DEMO_REPORT_DATA;
}