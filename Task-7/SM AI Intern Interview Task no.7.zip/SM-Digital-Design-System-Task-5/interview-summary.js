(function () {
  'use strict';

  // DOM Elements
  const overallScoreEl = document.getElementById('overall-score');
  const dimensionsGrid = document.getElementById('dimensions-grid');
  const recommendationBadge = document.getElementById('recommendation-badge');
  const recommendationText = document.getElementById('recommendation-text');
  const strengthsList = document.getElementById('strengths-list');
  const weaknessesList = document.getElementById('weaknesses-list');
  const quotesGrid = document.getElementById('quotes-grid');
  const downloadBtn = document.getElementById('download-report');

  // Use demo data (will be replaced with Athar's real data in Task 8)
  const reportData = typeof DEMO_REPORT_DATA !== 'undefined' ? DEMO_REPORT_DATA : {
    overallScore: 85,
    dimensions: [
      { name: "Technical Skills", score: 90, maxScore: 100 },
      { name: "Communication", score: 82, maxScore: 100 },
      { name: "Problem Solving", score: 88, maxScore: 100 },
      { name: "Cultural Fit", score: 78, maxScore: 100 }
    ],
    strengths: [
      "Strong technical background in web development and AI",
      "Excellent problem-solving approach with multiple solution strategies",
      "Good understanding of modern frameworks and best practices"
    ],
    weaknesses: [
      "Limited experience with large-scale enterprise applications",
      "Could improve knowledge of testing methodologies"
    ],
    recommendation: "Hire",
    keyQuotes: [
      {
        quote: "I think React has matured significantly over the years.",
        context: "Front-end frameworks discussion"
      },
      {
        quote: "I would implement several strategies: loading states, caching, and progressive loading.",
        context: "Technical challenge response"
      }
    ]
  };

  // Recommendation badge styling
  function getRecommendationBadgeClass(recommendation) {
    const badges = {
      'Strong Hire': 'strong-hire',
      'Hire': 'hire',
      'Maybe': 'maybe',
      'No Hire': 'no-hire'
    };
    return badges[recommendation] || 'maybe';
  }

  function getRecommendationIcon(recommendation) {
    const icons = {
      'Strong Hire': '🌟',
      'Hire': '🎯',
      'Maybe': '🤔',
      'No Hire': '❌'
    };
    return icons[recommendation] || '🤔';
  }

  // Animated counter for overall score
  function animateScore(targetScore, duration = 2000) {
    const startScore = 0;
    const startTime = performance.now();
    
    function updateScore(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const currentScore = Math.round(startScore + (targetScore - startScore) * easeOutQuart);
      
      overallScoreEl.textContent = currentScore;
      
      if (progress < 1) {
        requestAnimationFrame(updateScore);
      }
    }
    
    requestAnimationFrame(updateScore);
  }

  // Render dimension progress bars
  function renderDimensions() {
    dimensionsGrid.innerHTML = '';
    
    reportData.dimensions.forEach((dimension, index) => {
      const percentage = (dimension.score / dimension.maxScore) * 100;
      
      const dimensionEl = document.createElement('div');
      dimensionEl.className = 'dimension-item';
      dimensionEl.innerHTML = `
        <div class="dimension-header">
          <span class="dimension-name">${dimension.name}</span>
          <span class="dimension-score">${dimension.score}/${dimension.maxScore}</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" data-width="${percentage}%" style="width: 0%"></div>
        </div>
      `;
      
      dimensionsGrid.appendChild(dimensionEl);
      
      // Animate progress bar after a short delay
      setTimeout(() => {
        const progressFill = dimensionEl.querySelector('.progress-fill');
        progressFill.style.width = percentage + '%';
      }, 100 + (index * 150));
    });
  }

  // Render strengths
  function renderStrengths() {
    strengthsList.innerHTML = '';
    
    reportData.strengths.forEach((strength, index) => {
      const li = document.createElement('li');
      li.className = 'strength-item';
      li.innerHTML = `<span class="bullet">✓</span> ${strength}`;
      li.style.animationDelay = `${index * 100}ms`;
      strengthsList.appendChild(li);
    });
  }

  // Render weaknesses
  function renderWeaknesses() {
    weaknessesList.innerHTML = '';
    
    reportData.weaknesses.forEach((weakness, index) => {
      const li = document.createElement('li');
      li.className = 'weakness-item';
      li.innerHTML = `<span class="bullet">→</span> ${weakness}`;
      li.style.animationDelay = `${index * 100}ms`;
      weaknessesList.appendChild(li);
    });
  }

  // Render recommendation badge
  function renderRecommendation() {
    const badgeClass = getRecommendationBadgeClass(reportData.recommendation);
    const icon = getRecommendationIcon(reportData.recommendation);
    
    recommendationBadge.className = `recommendation-badge ${badgeClass}`;
    recommendationText.textContent = reportData.recommendation;
    
    const iconEl = recommendationBadge.querySelector('.recommendation-icon');
    if (iconEl) {
      iconEl.textContent = icon;
    }
  }

  // Render key quotes
  function renderQuotes() {
    quotesGrid.innerHTML = '';
    
    reportData.keyQuotes.forEach((quote, index) => {
      const quoteEl = document.createElement('div');
      quoteEl.className = 'quote-item';
      quoteEl.innerHTML = `
        <div class="quote-text">"${quote.quote}"</div>
        <div class="quote-context">— ${quote.context}</div>
      `;
      quoteEl.style.animationDelay = `${index * 150}ms`;
      quotesGrid.appendChild(quoteEl);
    });
  }

  // Download report functionality (placeholder for Task 8)
  function downloadReport() {
    // Placeholder download functionality
    // In Task 8, this will integrate with Athar's real report generation system
    console.log('Download report requested - placeholder for Task 8 integration');
    
    // Create a simple text file download as a placeholder
    const reportText = `
SM Digital AI Interview Report
==============================

Overall Score: ${reportData.overallScore}/100
Recommendation: ${reportData.recommendation}

Dimension Scores:
${reportData.dimensions.map(d => `- ${d.name}: ${d.score}/${d.maxScore}`).join('\n')}

Strengths:
${reportData.strengths.map(s => `- ${s}`).join('\n')}

Areas for Improvement:
${reportData.weaknesses.map(w => `- ${w}`).join('\n')}

Key Quotes:
${reportData.keyQuotes.map(q => `"${q.quote}" - ${q.context}`).join('\n')}

Generated: ${new Date().toISOString()}
    `.trim();
    
    const blob = new Blob([reportText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'interview-report.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // Initialize the summary page
  function init() {
    // Render all components
    renderDimensions();
    renderStrengths();
    renderWeaknesses();
    renderRecommendation();
    renderQuotes();
    
    // Start animations
    setTimeout(() => {
      animateScore(reportData.overallScore);
    }, 300);
    
    // Set up download button
    downloadBtn.addEventListener('click', downloadReport);
  }

  // Run initialization when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose for potential future integration
  window.InterviewSummaryAPI = {
    updateReportData: (newData) => {
      // This will be used to update with Athar's real data in Task 8
      Object.assign(reportData, newData);
      init();
    },
    getCurrentData: () => reportData
  };

}());