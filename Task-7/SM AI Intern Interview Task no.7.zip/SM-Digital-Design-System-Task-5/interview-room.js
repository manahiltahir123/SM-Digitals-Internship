(function () {
  'use strict';

  // DOM Elements
  const timerDisplay = document.getElementById('timer-display');
  const muteToggle = document.getElementById('mute-toggle');
  const muteIcon = document.getElementById('mute-icon');
  const muteText = document.getElementById('mute-text');
  const endInterviewBtn = document.getElementById('end-interview');
  const modalBackdrop = document.getElementById('modal-backdrop');
  const endInterviewModal = document.getElementById('end-interview-modal');
  const modalClose = document.getElementById('modal-close');
  const cancelEndBtn = document.getElementById('cancel-end');
  const confirmEndBtn = document.getElementById('confirm-end');
  const aiSpeakingIndicator = document.getElementById('ai-speaking-indicator');
  const transcriptContent = document.getElementById('transcript-content');

  // State
  let seconds = 0;
  let timerInterval = null;
  let isMuted = false;
  let isInterviewActive = true;

  // Timer Functions
  function formatTime(totalSeconds) {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }

  function startTimer() {
    if (timerInterval) return;
    timerInterval = setInterval(() => {
      seconds++;
      timerDisplay.textContent = formatTime(seconds);
    }, 1000);
  }

  function stopTimer() {
    if (timerInterval) {
      clearInterval(timerInterval);
      timerInterval = null;
    }
  }

  // Mute Toggle Functions
  function toggleMute() {
    isMuted = !isMuted;
    muteToggle.setAttribute('aria-pressed', isMuted);
    
    if (isMuted) {
      muteIcon.textContent = '🔇';
      muteText.textContent = 'Unmute';
      muteToggle.classList.add('muted');
    } else {
      muteIcon.textContent = '🎤';
      muteText.textContent = 'Mute';
      muteToggle.classList.remove('muted');
    }
  }

  // Modal Functions
  function showEndInterviewModal() {
    modalBackdrop.classList.remove('hidden');
    endInterviewModal.classList.remove('hidden');
    endInterviewBtn.disabled = true;
  }

  function hideEndInterviewModal() {
    modalBackdrop.classList.add('hidden');
    endInterviewModal.classList.add('hidden');
    endInterviewBtn.disabled = false;
  }

  function endInterview() {
    stopTimer();
    hideEndInterviewModal();
    isInterviewActive = false;
    
    // Redirect to interview summary page
    window.location.href = 'interview-summary.html';
  }

  // AI Speaking Indicator (Placeholder UI State)
  function setAISpeaking(isSpeaking) {
    if (isSpeaking) {
      aiSpeakingIndicator.hidden = false;
    } else {
      aiSpeakingIndicator.hidden = true;
    }
  }

  // Auto-scroll transcript to bottom (no longer needed with natural scrolling)
  function scrollToBottom() {
    // Function kept for compatibility but no longer auto-scrolls
    // Natural page scrolling handles this now
  }

  // Initialize
  function init() {
    // Start timer automatically when page loads
    startTimer();

    // Set up event listeners
    muteToggle.addEventListener('click', toggleMute);
    
    endInterviewBtn.addEventListener('click', showEndInterviewModal);
    
    modalClose.addEventListener('click', hideEndInterviewModal);
    cancelEndBtn.addEventListener('click', hideEndInterviewModal);
    
    confirmEndBtn.addEventListener('click', endInterview);

    // Close modal when clicking backdrop
    modalBackdrop.addEventListener('click', hideEndInterviewModal);

    // Keyboard accessibility for modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !modalBackdrop.classList.contains('hidden')) {
        hideEndInterviewModal();
      }
    });

    // No longer auto-scrolling - natural page scrolling instead
    // scrollToBottom();

    // Placeholder: Simulate AI speaking state for demo purposes
    // This will be replaced with real voice integration in Task 8
    setTimeout(() => {
      setAISpeaking(true);
      setTimeout(() => {
        setAISpeaking(false);
      }, 3000);
    }, 1000);
  }

  // Run initialization when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose functions for future voice integration (Task 8)
  window.InterviewRoomAPI = {
    setAISpeaking,
    addMessage: (sender, text, time) => {
      // Placeholder for adding messages dynamically
      // This will be used by the real voice pipeline
      console.log('Message added:', { sender, text, time });
    },
    endInterview,
    isInterviewActive: () => isInterviewActive
  };

}());