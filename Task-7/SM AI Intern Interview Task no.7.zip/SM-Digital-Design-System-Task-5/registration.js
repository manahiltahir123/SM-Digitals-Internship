(function () {
  const form = document.querySelector('#intern-registration-form');
  if (!form) return;

  const fileInput = document.querySelector('#cv');
  const uploadZone = document.querySelector('#upload-zone');
  const fileSummary = document.querySelector('#file-summary');
  const fileDetails = document.querySelector('#file-details');
  const status = document.querySelector('#form-status');
  const submitButton = document.querySelector('#submit-button');
  const browseButton = document.querySelector('#browse-cv');
  const replaceButton = document.querySelector('#replace-cv');
  const removeButton = document.querySelector('#remove-cv');
  let selectedFile = null;
  let submitting = false;

  const fields = ['fullName', 'email', 'phone', 'cnic', 'permanentAddress', 'currentAddress'];
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phonePattern = /^(?:\+92|92|0)?3\d{9}$/;
  const cnicPattern = /^\d{13}$/;

  function setError(name, message) {
    const input = document.querySelector(`#${name}`);
    const messageEl = document.querySelector(`#${name}-error`);
    if (input) input.setAttribute('aria-invalid', Boolean(message));
    if (messageEl) messageEl.textContent = message || '';
  }

  function normalizePhone(value) { return value.replace(/[\s()-]/g, ''); }
  function normalizeCnic(value) { return value.replace(/[-\s]/g, ''); }
  function fileSize(bytes) { return `${(bytes / (1024 * 1024)).toFixed(bytes < 1024 * 1024 ? 2 : 1)} MB`; }

  function validateField(name) {
    const input = document.querySelector(`#${name}`);
    const value = input.value.trim();
    let message = '';
    if (!value) message = 'This field is required.';
    else if (name === 'email' && !emailPattern.test(value)) message = 'Enter a valid email address.';
    else if (name === 'phone' && !phonePattern.test(normalizePhone(value))) message = 'Enter a valid Pakistani mobile number (for example, 03001234567).';
    else if (name === 'cnic' && !cnicPattern.test(normalizeCnic(value))) message = 'Enter a valid 13-digit CNIC (for example, 35202-1234567-1).';
    setError(name, message);
    return !message;
  }

  function validateFile(file = selectedFile) {
    let message = '';
    if (!file) message = 'Please upload your CV.';
    else if (!/\.pdf$/i.test(file.name) || file.type && file.type !== 'application/pdf') message = 'Your CV must be a PDF file.';
    else if (file.size > 5 * 1024 * 1024) message = 'Your CV must be 5 MB or smaller.';
    document.querySelector('#cv-error').textContent = message;
    uploadZone.classList.toggle('is-invalid', Boolean(message));
    return !message;
  }

  function updateFile(file) {
    if (!validateFile(file)) {
      selectedFile = null;
      fileInput.value = '';
      fileSummary.hidden = true;
      return;
    }
    selectedFile = file;
    fileDetails.innerHTML = `<strong>${escapeHtml(file.name)}</strong><br>${fileSize(file.size)}`;
    fileSummary.hidden = false;
  }

  function clearFile(event) {
    event?.preventDefault();
    event?.stopPropagation();
    selectedFile = null;
    fileInput.value = '';
    fileDetails.textContent = '';
    fileSummary.hidden = true;
    document.querySelector('#cv-error').textContent = '';
    uploadZone.classList.remove('is-invalid');
  }

  function escapeHtml(value) {
    const span = document.createElement('span');
    span.textContent = value;
    return span.innerHTML;
  }

  function setStatus(message, kind) {
    status.hidden = !message;
    status.textContent = message || '';
    status.className = `form-status form-status--${kind || 'error'}`;
  }

  function setSubmitting(value) {
    submitting = value;
    submitButton.disabled = value;
    submitButton.textContent = value ? 'Registering…' : 'Register & Continue';
    fields.forEach((name) => { document.querySelector(`#${name}`).disabled = value; });
    fileInput.disabled = value;
    browseButton.disabled = value;
    replaceButton.disabled = value;
    removeButton.disabled = value;
  }

  fields.forEach((name) => {
    const input = document.querySelector(`#${name}`);
    input.addEventListener('blur', () => validateField(name));
    input.addEventListener('input', () => { if (input.getAttribute('aria-invalid') === 'true') validateField(name); });
  });

  fileInput.addEventListener('change', () => updateFile(fileInput.files[0]));
  browseButton.addEventListener('click', () => fileInput.click());
  replaceButton.addEventListener('click', () => fileInput.click());
  removeButton.addEventListener('click', clearFile);
  ['dragenter', 'dragover'].forEach((eventName) => uploadZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    if (!submitting) uploadZone.classList.add('is-dragging');
  }));
  ['dragleave', 'drop'].forEach((eventName) => uploadZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    uploadZone.classList.remove('is-dragging');
  }));
  uploadZone.addEventListener('drop', (event) => {
    if (!submitting) updateFile(event.dataTransfer.files[0]);
  });
  uploadZone.addEventListener('keydown', (event) => {
    if ((event.key === 'Enter' || event.key === ' ') && !submitting) {
      event.preventDefault();
      fileInput.click();
    }
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (submitting) return;
    setStatus('');
    const isValid = fields.map(validateField).every(Boolean) && validateFile();
    if (!isValid) {
      setStatus('Please correct the highlighted fields and try again.', 'error');
      form.querySelector('[aria-invalid="true"]')?.focus();
      return;
    }
    setSubmitting(true);
    try {
      await window.InternRegistrationService.submitInternRegistration({
        fullName: document.querySelector('#fullName').value.trim(),
        email: document.querySelector('#email').value.trim(),
        phone: document.querySelector('#phone').value.trim(),
        cnic: document.querySelector('#cnic').value.trim(),
        permanentAddress: document.querySelector('#permanentAddress').value.trim(),
        currentAddress: document.querySelector('#currentAddress').value.trim(),
        cv: selectedFile
      });
      setStatus('Registration successful. Taking you to Mic Check…', 'success');
      window.setTimeout(() => { window.location.href = 'mic-check.html'; }, 700);
    } catch (error) {
      setStatus(error?.message || 'We could not submit your registration. Please try again.', 'error');
      setSubmitting(false);
    }
  });
}());
