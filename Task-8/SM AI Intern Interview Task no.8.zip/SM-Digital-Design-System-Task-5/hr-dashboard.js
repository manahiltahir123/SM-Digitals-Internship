/*
 * HR Dashboard - SM Digital AI Interview Platform
 * 
 * This file handles the HR Dashboard functionality including:
 * - Demo candidate data
 * - Statistics calculation
 * - Filter tabs functionality
 * - Search functionality
 * - Sort functionality
 * - Candidate card rendering
 */

// Demo candidate data - This will be replaced with real Athar data when available
const DEMO_CANDIDATES = [
  {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    position: "Frontend Developer",
    interviewDate: "2025-01-15T10:30:00Z",
    status: "interviewed",
    overallScore: 92,
    recommendation: "Strong Hire",
    dimensions: {
      technical: 95,
      communication: 88,
      problemSolving: 91,
      culturalFit: 92
    }
  },
  {
    id: 2,
    name: "Michael Chen",
    email: "michael.chen@email.com",
    position: "Backend Developer",
    interviewDate: "2025-01-14T14:00:00Z",
    status: "shortlisted",
    overallScore: 88,
    recommendation: "Hire",
    dimensions: {
      technical: 90,
      communication: 85,
      problemSolving: 89,
      culturalFit: 87
    }
  },
  {
    id: 3,
    name: "Emily Rodriguez",
    email: "emily.rodriguez@email.com",
    position: "Full Stack Developer",
    interviewDate: "2025-01-13T09:00:00Z",
    status: "rejected",
    overallScore: 65,
    recommendation: "No Hire",
    dimensions: {
      technical: 68,
      communication: 72,
      problemSolving: 58,
      culturalFit: 62
    }
  },
  {
    id: 4,
    name: "David Kim",
    email: "david.kim@email.com",
    position: "DevOps Engineer",
    interviewDate: "2025-01-12T16:30:00Z",
    status: "interviewed",
    overallScore: 78,
    recommendation: "Maybe",
    dimensions: {
      technical: 82,
      communication: 75,
      problemSolving: 76,
      culturalFit: 79
    }
  },
  {
    id: 5,
    name: "Jennifer Martinez",
    email: "jennifer.martinez@email.com",
    position: "Frontend Developer",
    interviewDate: "2025-01-11T11:00:00Z",
    status: "shortlisted",
    overallScore: 85,
    recommendation: "Hire",
    dimensions: {
      technical: 87,
      communication: 83,
      problemSolving: 84,
      culturalFit: 86
    }
  },
  {
    id: 6,
    name: "Robert Thompson",
    email: "robert.thompson@email.com",
    position: "Backend Developer",
    interviewDate: "2025-01-10T13:30:00Z",
    status: "pending",
    overallScore: null,
    recommendation: null,
    dimensions: null
  },
  {
    id: 7,
    name: "Amanda Lee",
    email: "amanda.lee@email.com",
    position: "Full Stack Developer",
    interviewDate: "2025-01-09T10:00:00Z",
    status: "interviewed",
    overallScore: 90,
    recommendation: "Strong Hire",
    dimensions: {
      technical: 92,
      communication: 88,
      problemSolving: 90,
      culturalFit: 89
    }
  },
  {
    id: 8,
    name: "Christopher Wilson",
    email: "christopher.wilson@email.com",
    position: "Frontend Developer",
    interviewDate: "2025-01-08T15:00:00Z",
    status: "rejected",
    overallScore: 55,
    recommendation: "No Hire",
    dimensions: {
      technical: 52,
      communication: 68,
      problemSolving: 48,
      culturalFit: 55
    }
  },
  {
    id: 9,
    name: "Jessica Brown",
    email: "jessica.brown@email.com",
    position: "DevOps Engineer",
    interviewDate: "2025-01-07T09:30:00Z",
    status: "pending",
    overallScore: null,
    recommendation: null,
    dimensions: null
  },
  {
    id: 10,
    name: "Daniel Garcia",
    email: "daniel.garcia@email.com",
    position: "Backend Developer",
    interviewDate: "2025-01-06T14:00:00Z",
    status: "shortlisted",
    overallScore: 82,
    recommendation: "Hire",
    dimensions: {
      technical: 85,
      communication: 80,
      problemSolving: 81,
      culturalFit: 82
    }
  }
];

// State management
let currentFilter = 'all';
let currentSearch = '';
let currentSort = 'newest';

// DOM Elements
const statPending = document.getElementById('stat-pending');
const statInterviewed = document.getElementById('stat-interviewed');
const statShortlisted = document.getElementById('stat-shortlisted');
const statRejected = document.getElementById('stat-rejected');
const filterTabs = document.querySelectorAll('.filter-tab');
const searchInput = document.getElementById('search-input');
const sortSelect = document.getElementById('sort-select');
const interviewList = document.getElementById('interview-list');
const noResults = document.getElementById('no-results');

// Initialize dashboard
function initDashboard() {
  updateStats();
  renderCandidates();
  setupEventListeners();
}

// Update statistics
function updateStats() {
  const pending = DEMO_CANDIDATES.filter(c => c.status === 'pending').length;
  const interviewed = DEMO_CANDIDATES.filter(c => c.status === 'interviewed').length;
  const shortlisted = DEMO_CANDIDATES.filter(c => c.status === 'shortlisted').length;
  const rejected = DEMO_CANDIDATES.filter(c => c.status === 'rejected').length;

  animateNumber(statPending, pending);
  animateNumber(statInterviewed, interviewed);
  animateNumber(statShortlisted, shortlisted);
  animateNumber(statRejected, rejected);
}

// Animate number counter
function animateNumber(element, target) {
  let current = 0;
  const increment = target / 20;
  const duration = 800;
  const stepTime = duration / 20;

  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      element.textContent = target;
      clearInterval(timer);
    } else {
      element.textContent = Math.floor(current);
    }
  }, stepTime);
}

// Filter and sort candidates
function getFilteredAndSortedCandidates() {
  let candidates = [...DEMO_CANDIDATES];

  // Apply filter
  if (currentFilter !== 'all') {
    candidates = candidates.filter(c => c.status === currentFilter);
  }

  // Apply search
  if (currentSearch) {
    const searchLower = currentSearch.toLowerCase();
    candidates = candidates.filter(c => 
      c.name.toLowerCase().includes(searchLower) ||
      c.email.toLowerCase().includes(searchLower) ||
      c.status.toLowerCase().includes(searchLower) ||
      c.position.toLowerCase().includes(searchLower)
    );
  }

  // Apply sort
  switch (currentSort) {
    case 'newest':
      candidates.sort((a, b) => new Date(b.interviewDate) - new Date(a.interviewDate));
      break;
    case 'oldest':
      candidates.sort((a, b) => new Date(a.interviewDate) - new Date(b.interviewDate));
      break;
    case 'highest-score':
      candidates.sort((a, b) => (b.overallScore || 0) - (a.overallScore || 0));
      break;
    case 'lowest-score':
      candidates.sort((a, b) => (a.overallScore || 0) - (b.overallScore || 0));
      break;
    case 'name-asc':
      candidates.sort((a, b) => a.name.localeCompare(b.name));
      break;
    case 'name-desc':
      candidates.sort((a, b) => b.name.localeCompare(a.name));
      break;
  }

  return candidates;
}

// Render candidate cards
function renderCandidates() {
  const candidates = getFilteredAndSortedCandidates();

  if (candidates.length === 0) {
    interviewList.innerHTML = '';
    noResults.classList.remove('hidden');
    return;
  }

  noResults.classList.add('hidden');
  interviewList.innerHTML = candidates.map(candidate => createCandidateCard(candidate)).join('');
}

// Create candidate card HTML
function createCandidateCard(candidate) {
  const formattedDate = formatDate(candidate.interviewDate);
  const statusBadge = getStatusBadge(candidate.status);
  const scoreDisplay = candidate.overallScore !== null 
    ? `<div class="candidate-score">
        <span class="score-label">Score:</span>
        <span class="score-value">${candidate.overallScore}/100</span>
       </div>`
    : '';
  const recommendationBadge = candidate.recommendation 
    ? getRecommendationBadge(candidate.recommendation)
    : '';

  return `
    <article class="card" data-id="${candidate.id}">
      <div class="candidate-header">
        <div class="candidate-info">
          <h3 class="candidate-name">${candidate.name}</h3>
          <p class="candidate-email">${candidate.email}</p>
          <p class="candidate-position">${candidate.position}</p>
        </div>
        <div class="candidate-status">
          ${statusBadge}
        </div>
      </div>
      <div class="candidate-details">
        <div class="candidate-date">
          <span class="date-icon">📅</span>
          <span>${formattedDate}</span>
        </div>
        ${scoreDisplay}
        ${recommendationBadge}
      </div>
      <div class="candidate-actions">
        <button class="btn primary-btn view-interview-btn" aria-label="View interview for ${candidate.name}">
          <span class="view-icon">👁️</span>
          <span>View Interview</span>
        </button>
      </div>
    </article>
  `;
}

// Format date
function formatDate(dateString) {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Get status badge HTML
function getStatusBadge(status) {
  const badges = {
    pending: '<span class="badge pending-badge">Pending</span>',
    interviewed: '<span class="badge interview-badge">Interviewed</span>',
    shortlisted: '<span class="badge success-badge">Shortlisted</span>',
    rejected: '<span class="badge reject-badge">Rejected</span>'
  };
  return badges[status] || '';
}

// Get recommendation badge HTML
function getRecommendationBadge(recommendation) {
  const badges = {
    'Strong Hire': '<span class="recommendation-badge-small strong-hire">Strong Hire</span>',
    'Hire': '<span class="recommendation-badge-small hire">Hire</span>',
    'Maybe': '<span class="recommendation-badge-small maybe">Maybe</span>',
    'No Hire': '<span class="recommendation-badge-small no-hire">No Hire</span>'
  };
  return badges[recommendation] || '';
}

// Setup event listeners
function setupEventListeners() {
  // Filter tabs
  filterTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      filterTabs.forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
      });
      tab.classList.add('active');
      tab.setAttribute('aria-selected', 'true');
      currentFilter = tab.dataset.filter;
      renderCandidates();
    });
  });

  // Search input
  searchInput.addEventListener('input', (e) => {
    currentSearch = e.target.value;
    renderCandidates();
  });

  // Sort select
  sortSelect.addEventListener('change', (e) => {
    currentSort = e.target.value;
    renderCandidates();
  });

  // View interview buttons (placeholder functionality)
  interviewList.addEventListener('click', (e) => {
    const viewBtn = e.target.closest('.view-interview-btn');
    if (viewBtn) {
      const card = viewBtn.closest('.card');
      const candidateId = card.dataset.id;
      // Placeholder: Navigate to interview details when implemented
      console.log('View interview for candidate:', candidateId);
      alert('Interview details view will be implemented in a future task.');
    }
  });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initDashboard);
} else {
  initDashboard();
}